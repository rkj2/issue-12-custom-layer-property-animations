//
//  ViewController.swift
//  AnimatedClock
//
//  Created by Rajive Jain on 4/23/16.
//  Copyright © 2016 Rajive Jain. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var datePicker: UIDatePicker!
    var clockFace: ClockFace = ClockFace()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //clock face
        
        self.clockFace.position = CGPointMake(self.view.bounds.size.width / 2, 150)
        self.view.layer.addSublayer(self.clockFace)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func setTime(sender: UIButton) {
        self.clockFace.theTime = self.datePicker.date
    }

}


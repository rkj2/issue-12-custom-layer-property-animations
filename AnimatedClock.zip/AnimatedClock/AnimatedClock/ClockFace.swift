//
//  ClockFace.swift
//  AnimatedClock
//
//  Created by Rajive Jain on 4/23/16.
//  Copyright © 2016 Rajive Jain. All rights reserved.
//

import Foundation
import QuartzCore
import CoreGraphics
import UIKit


class ClockFace: CAShapeLayer {
    
    var hourHand: CAShapeLayer
    var minuteHand: CAShapeLayer
    
    var theTime: NSDate {
        didSet {
            let calendar: NSCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
            let components: NSDateComponents = calendar.components([.Hour,.Minute], fromDate: self.theTime)
            let hourValue = Double(components.hour) / 12.0 * Double(2.0 * M_PI)
            let minuteValue = Double(components.minute) / 60.0 * Double(2.0 * M_PI)
            self.hourHand.setAffineTransform(CGAffineTransformMakeRotation(CGFloat(hourValue)))
            self.minuteHand.setAffineTransform(CGAffineTransformMakeRotation(CGFloat(minuteValue)))
        }
       
        
    }

    override init() {
        
        //hour hand
        self.hourHand = CAShapeLayer()
        let hourPath : UIBezierPath = UIBezierPath(rect: CGRectMake(-2, -70, 4, 70))
        self.hourHand.path = hourPath.CGPath
        self.hourHand.fillColor = UIColor.whiteColor().CGColor
        
        //minute hand 
        self.minuteHand = CAShapeLayer()
        let minutePath : UIBezierPath = UIBezierPath(rect: CGRectMake(-1, -90, 2, 90))
        self.minuteHand.path = minutePath.CGPath
        self.minuteHand.fillColor = UIColor.whiteColor().CGColor
        
        self.theTime = NSDate()
    
        super.init()
        
        self.bounds = CGRectMake(0, 0, 200, 200)
        self.path = UIBezierPath(ovalInRect: self.bounds).CGPath
        self.fillColor = UIColor.orangeColor().CGColor
        self.strokeColor = UIColor.whiteColor().CGColor
        self.lineWidth = 2
        
        self.hourHand.position = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2)
        self.minuteHand.position = CGPointMake(self.bounds.size.width / 2, self.bounds.size.height / 2)
        self.addSublayer(self.hourHand)
        self.addSublayer(self.minuteHand)
        
        //date


    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}